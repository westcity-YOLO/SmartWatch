# BMV080 SDK

The BMV080 binaries in the `api` directory are licensed under the [Bosch Sensortec GmbH Standard Software License](#bst-standard-software-license). The BMV080 binaries do not include any open source software.

The application examples in the `api_examples` directory are licensed under the [Bosch Sensortec GmbH Standard Software License](#bst-standard-software-license).

All other dependencies in the `api_examples` directory are licensed under their respective clauses as described in [Third-Party Licenses](#third-party-licenses---api-examples).

The web application in the `apps` directory is licensed under the [Bosch Sensortec GmbH Standard Software License](#bst-standard-software-license). It has dependencies which is are listed along with their respective clauses in [Third-Party Licenses](#third-party-licenses---web-app).

### BST Standard Software License

Copyright (c) 2020 - 2025 Bosch Sensortec GmbH

Bosch Sensortec products are developed for the consumer goods industry. They may only be used within the parameters of the respective valid product data sheet. Bosch Sensortec products are provided with the express understanding that there is no warranty of fitness for a particular purpose. They are not fit for use in life-sustaining, safety or security sensitive systems or any system or device that may lead to bodily harm or property damage if the system or device malfunctions. In addition, Bosch Sensortec products are not fit for use in products which interact with motor vehicle systems. The resale and/or use of products are at the purchaser's own risk and his own responsibility. The examination of fitness for the intended use is the sole responsibility of the Purchaser.

The purchaser shall indemnify Bosch Sensortec from all third party claims, including any claims for incidental, or consequential damages, arising from any product use not covered by the parameters of the respective valid product data sheet or not approved by Bosch Sensortec and reimburse Bosch Sensortec for all costs in connection with such claims.

The purchaser must monitor the market for the purchased products, particularly with regard to product safety and inform Bosch Sensortec without delay of all security relevant incidents.

Engineering Samples are marked with an asterisk (*) or (e). Samples may vary from the valid technical specifications of the product series. They are therefore not intended or fit for resale to third parties or for use in end products. Their sole purpose is internal client testing. The testing of an engineering sample may in no way replace the testing of a product series. Bosch Sensortec assumes no liability for the use of engineering samples. By accepting the engineering samples, the Purchaser agrees to indemnify Bosch Sensortec from all claims arising from the use of engineering samples.

Special:

This software module (hereinafter called "Software") and any information on application-sheets (hereinafter called "Information") is provided free of charge for the sole purpose to support your application work. The Software and Information is subject to the following terms and conditions:

The Software is specifically designed for the exclusive use for Bosch Sensortec products by personnel who have special experience and training. Do not use this Software if you do not have the proper experience or training.

This Software package is provided `` as is `` and without any expressed or implied warranties, including without limitation, the implied warranties of merchantability and fitness for a particular purpose.

Bosch Sensortec and their representatives and agents deny any liability for the functional impairment of this Software in terms of fitness, performance and safety. Bosch Sensortec and their representatives and agents shall not be liable for any direct or indirect damages or injury, except as otherwise stipulated in mandatory applicable law.

The Information provided is believed to be accurate and reliable. Bosch Sensortec assumes no responsibility for the consequences of use of such Information nor for any infringement of patents or other rights of third parties which may result from its use. No license is granted by implication or otherwise under any patent or patent rights of Bosch. Specifications mentioned in the Information are subject to change without notice.

It is neither permitted to deliver the source code of the Software to any third party without permission of Bosch Sensortec, nor to apply any measures to re-engineer or reverse-analyze the software delivered.

## Third-Party Licenses - API Examples
#### [D2XX Drivers](https://ftdichip.com/drivers/d2xx-drivers/)  
Copyright (c) 2001-2011 Future Technology Devices International Limited

Version 2.12.28

This software is provided by Future Technology Devices International Limited `` as is `` and any express or implied warranties, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose are disclaimed. In no event shall future technology devices international limited be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this software, even if advised of the possibility of such damage.
FTDI drivers may be used only in conjunction with products based on FTDI parts.
FTDI drivers may be distributed in any form as long as license information is not modified.
If a custom vendor ID and/or product ID or description string are used, it is the responsibility of the product manufacturer to maintain any changes and subsequent WHCK re-certification as a result of making these changes.
For more detail on FTDI Chip Driver license terms, please click [here](https://ftdichip.com/driver-licence-terms/).


#### [LibFT4222 Windows Library](https://ftdichip.com/software-examples/ft4222h-software-examples/)  
Copyright (c) 2001-2015 Future Technology Devices International Limited

Version 1.4.2.184

This software is provided by Future Technology Devices International Limited `` as is `` and any express or implied warranties, including, but not limited to, the implied warranties of merchantability and fitness for a particular purpose are disclaimed. In no event shall future technology devices international limited be liable for any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not limited to, procurement of substitute goods or services; loss of use, data, or profits; or business interruption) however caused and on any theory of liability, whether in contract, strict liability, or tort (including negligence or otherwise) arising in any way out of the use of this software, even if advised of the possibility of such damage.

#### [PlatformIO Core](https://github.com/platformio/platformio-core)  
Copyright (c) 2014-2023 PlatformIO Labs

Version 6.1.17

License: [Apache 2.0](#apache-license)

#### [CMSIS](https://github.com/ARM-software/CMSIS_5/tree/5.4.0) 
Copyright (c) 2009-2017 ARM Limited. All rights reserved.

Version 5.4.0

License: [Apache 2.0](#apache-license)

#### [CMSIS Device](https://github.com/STMicroelectronics/cmsis_device_f4/tree/v2.6.7)
Copyright (c) 2017 ARM Limited - STMicroelectronics

Version 2.6.7

License: [Apache 2.0](#apache-license)

#### [STM32F4 HAL](https://github.com/STMicroelectronics/stm32f4xx_hal_driver/tree/v1.7.13) 
Copyright (c) 2016, 2022 STMicroelectronics 

Version 1.7.13 

License: [BSD-3-Clause](#bsd-3-clause)

#### [STM32_USB_Device_Library](https://github.com/STMicroelectronics/STM32CubeWB/tree/v1.2.0/Middlewares/ST/STM32_USB_Device_Library/Class/CDC)
Copyright (c) 2015, 2022 STMicroelectronics 

Version 1.2

License: [SLA0044](#st-microelectronics---sla0044---ultimate-liberty-software-license-agreement)

#### [STM32CubeF4 MCU Firmware Package](https://github.com/STMicroelectronics/STM32CubeF4/tree/v1.26.2)
Copyright (c) 2017, 2022 STMicroelectronics 

Version 1.26.2

License: [SLA0044](#st-microelectronics---sla0044---ultimate-liberty-software-license-agreement), [BSD-3-Clause](#bsd-3-clause), [Apache 2.0](#apache-license), [MIT](#mit-license)

#### [Espressif IoT Development Framework (ESP-IDF)](https://github.com/espressif/esp-idf/releases/tag/v5.4.1)
Copyright (c) 2016 - 2023, Espressif Systems (Shanghai) Co., Ltd.

Version 5.4.1

License: [Apache 2.0](#apache-license)

#### [Arduino Core - Renesas FSP](https://github.com/arduino/ArduinoCore-renesas/releases/tag/1.1.0) 
Copyright (c) 2022-2023 Arduino SA

Version 1.1.0

License: [MIT](#mit-license)

#### [Bosch Sensortec COINES SDK](https://github.com/boschsensortec/COINES_SDK/releases/tag/COINES_SDK_v2.10) 
Copyright (c) 2024 Bosch Sensortec GmbH. All rights reserved.

Version 2.10.4

License: [COINES SDK Software License Agreement](https://github.com/boschsensortec/COINES_SDK/blob/main/COINES_SDK_SoftwareLicenseAgreement.txt)


## Third-Party Licenses - Web App

#### [Bosch Sensortec COINES SDK](https://github.com/boschsensortec/COINES_SDK/releases/tag/COINES_SDK_v2.10) 
Copyright (c) 2024 Bosch Sensortec GmbH. All rights reserved.

Version 2.10.4

License: [COINES SDK Software License Agreement](https://github.com/boschsensortec/COINES_SDK/blob/main/COINES_SDK_SoftwareLicenseAgreement.txt)

#### [JQuery](https://github.com/jquery/jquery/releases/tag/3.4.1)
Copyright (c) 2005, 2014 jQuery Foundation, Inc.

Version 3.4.1

License: [MIT](#mit-license)

#### [Material Components Web](https://github.com/material-components/material-components-web/releases/tag/v14.0.0)

Copyright (c) 2014-2020 Google Inc.

Version 14.0.0

License: [MIT](#mit-license)

#### [Material Design Icons](https://github.com/google/material-design-icons/releases/tag/4.0.0)

Copyright: (c) 2020 Google Inc.

Version 4.0.0

License: [Apache 2.0](#apache-license)

#### [Normalize](https://github.com/necolas/normalize.css/releases/tag/7.0.0)

Copyright (c) 2016 Nicolas Gallagher and Jonathan Neal

Version 7.0.0

License: [MIT](#mit-license)

#### [Plotly](https://github.com/plotly/plotly.js/releases/tag/v3.0.1)

Copyright (c) 2025 Plotly, Inc.

Version 3.0.1

License: [MIT](#mit-license)

#### [Just Gage](https://github.com/toorshia/justgage/releases/tag/1.2.2)

Copyright (c) 2012-2015 Bojan Djuricic

Version 1.2.2

License: [MIT](#mit-license)

#### [Raphael Vector Library](https://github.com/DmitryBaranovskiy/raphael/releases/tag/v2.1.4)
Copyright (c) 2008-2012 Dmitry Baranovskiy (http://raphaeljs.com)
Copyright (c) 2008-2012 Sencha Labs (http://sencha.com)

Version 2.1.4

License: [MIT](#mit-license)

#### [Loaders](https://github.com/ConnorAtherton/loaders.css/releases/tag/0.1.2)
Copyright (c) 2016 Connor Atherton

Version 0.1.2

License: [MIT](#mit-license)


### BSD 3 Clause

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

### Apache License

_Version 2.0, January 2004_  
_&lt;<http://www.apache.org/licenses/>&gt;_

#### Terms and Conditions for use, reproduction, and distribution

##### 1. Definitions

“License” shall mean the terms and conditions for use, reproduction, and
distribution as defined by Sections 1 through 9 of this document.

“Licensor” shall mean the copyright owner or entity authorized by the copyright
owner that is granting the License.

“Legal Entity” shall mean the union of the acting entity and all other entities
that control, are controlled by, or are under common control with that entity.
For the purposes of this definition, “control” means **(i)** the power, direct or
indirect, to cause the direction or management of such entity, whether by
contract or otherwise, or **(ii)** ownership of fifty percent (50%) or more of the
outstanding shares, or **(iii)** beneficial ownership of such entity.

“You” (or “Your”) shall mean an individual or Legal Entity exercising
permissions granted by this License.

“Source” form shall mean the preferred form for making modifications, including
but not limited to software source code, documentation source, and configuration
files.

“Object” form shall mean any form resulting from mechanical transformation or
translation of a Source form, including but not limited to compiled object code,
generated documentation, and conversions to other media types.

“Work” shall mean the work of authorship, whether in Source or Object form, made
available under the License, as indicated by a copyright notice that is included
in or attached to the work (an example is provided in the Appendix below).

“Derivative Works” shall mean any work, whether in Source or Object form, that
is based on (or derived from) the Work and for which the editorial revisions,
annotations, elaborations, or other modifications represent, as a whole, an
original work of authorship. For the purposes of this License, Derivative Works
shall not include works that remain separable from, or merely link (or bind by
name) to the interfaces of, the Work and Derivative Works thereof.

“Contribution” shall mean any work of authorship, including the original version
of the Work and any modifications or additions to that Work or Derivative Works
thereof, that is intentionally submitted to Licensor for inclusion in the Work
by the copyright owner or by an individual or Legal Entity authorized to submit
on behalf of the copyright owner. For the purposes of this definition,
“submitted” means any form of electronic, verbal, or written communication sent
to the Licensor or its representatives, including but not limited to
communication on electronic mailing lists, source code control systems, and
issue tracking systems that are managed by, or on behalf of, the Licensor for
the purpose of discussing and improving the Work, but excluding communication
that is conspicuously marked or otherwise designated in writing by the copyright
owner as “Not a Contribution.”

“Contributor” shall mean Licensor and any individual or Legal Entity on behalf
of whom a Contribution has been received by Licensor and subsequently
incorporated within the Work.

##### 2. Grant of Copyright License

Subject to the terms and conditions of this License, each Contributor hereby
grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free,
irrevocable copyright license to reproduce, prepare Derivative Works of,
publicly display, publicly perform, sublicense, and distribute the Work and such
Derivative Works in Source or Object form.

##### 3. Grant of Patent License

Subject to the terms and conditions of this License, each Contributor hereby
grants to You a perpetual, worldwide, non-exclusive, no-charge, royalty-free,
irrevocable (except as stated in this section) patent license to make, have
made, use, offer to sell, sell, import, and otherwise transfer the Work, where
such license applies only to those patent claims licensable by such Contributor
that are necessarily infringed by their Contribution(s) alone or by combination
of their Contribution(s) with the Work to which such Contribution(s) was
submitted. If You institute patent litigation against any entity (including a
cross-claim or counterclaim in a lawsuit) alleging that the Work or a
Contribution incorporated within the Work constitutes direct or contributory
patent infringement, then any patent licenses granted to You under this License
for that Work shall terminate as of the date such litigation is filed.

##### 4. Redistribution

You may reproduce and distribute copies of the Work or Derivative Works thereof
in any medium, with or without modifications, and in Source or Object form,
provided that You meet the following conditions:

* **(a)** You must give any other recipients of the Work or Derivative Works a copy of
this License; and
* **(b)** You must cause any modified files to carry prominent notices stating that You
changed the files; and
* **(c)** You must retain, in the Source form of any Derivative Works that You distribute,
all copyright, patent, trademark, and attribution notices from the Source form
of the Work, excluding those notices that do not pertain to any part of the
Derivative Works; and
* **(d)** If the Work includes a “NOTICE” text file as part of its distribution, then any
Derivative Works that You distribute must include a readable copy of the
attribution notices contained within such NOTICE file, excluding those notices
that do not pertain to any part of the Derivative Works, in at least one of the
following places: within a NOTICE text file distributed as part of the
Derivative Works; within the Source form or documentation, if provided along
with the Derivative Works; or, within a display generated by the Derivative
Works, if and wherever such third-party notices normally appear. The contents of
the NOTICE file are for informational purposes only and do not modify the
License. You may add Your own attribution notices within Derivative Works that
You distribute, alongside or as an addendum to the NOTICE text from the Work,
provided that such additional attribution notices cannot be construed as
modifying the License.

You may add Your own copyright statement to Your modifications and may provide
additional or different license terms and conditions for use, reproduction, or
distribution of Your modifications, or for any such Derivative Works as a whole,
provided Your use, reproduction, and distribution of the Work otherwise complies
with the conditions stated in this License.

##### 5. Submission of Contributions

Unless You explicitly state otherwise, any Contribution intentionally submitted
for inclusion in the Work by You to the Licensor shall be under the terms and
conditions of this License, without any additional terms or conditions.
Notwithstanding the above, nothing herein shall supersede or modify the terms of
any separate license agreement you may have executed with Licensor regarding
such Contributions.

##### 6. Trademarks

This License does not grant permission to use the trade names, trademarks,
service marks, or product names of the Licensor, except as required for
reasonable and customary use in describing the origin of the Work and
reproducing the content of the NOTICE file.

##### 7. Disclaimer of Warranty

Unless required by applicable law or agreed to in writing, Licensor provides the
Work (and each Contributor provides its Contributions) on an “AS IS” BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied,
including, without limitation, any warranties or conditions of TITLE,
NON-INFRINGEMENT, MERCHANTABILITY, or FITNESS FOR A PARTICULAR PURPOSE. You are
solely responsible for determining the appropriateness of using or
redistributing the Work and assume any risks associated with Your exercise of
permissions under this License.

##### 8. Limitation of Liability

In no event and under no legal theory, whether in tort (including negligence),
contract, or otherwise, unless required by applicable law (such as deliberate
and grossly negligent acts) or agreed to in writing, shall any Contributor be
liable to You for damages, including any direct, indirect, special, incidental,
or consequential damages of any character arising as a result of this License or
out of the use or inability to use the Work (including but not limited to
damages for loss of goodwill, work stoppage, computer failure or malfunction, or
any and all other commercial damages or losses), even if such Contributor has
been advised of the possibility of such damages.

##### 9. Accepting Warranty or Additional Liability

While redistributing the Work or Derivative Works thereof, You may choose to
offer, and charge a fee for, acceptance of support, warranty, indemnity, or
other liability obligations and/or rights consistent with this License. However,
in accepting such obligations, You may act only on Your own behalf and on Your
sole responsibility, not on behalf of any other Contributor, and only if You
agree to indemnify, defend, and hold each Contributor harmless for any liability
incurred by, or claims asserted against, such Contributor by reason of your
accepting any such warranty or additional liability.

_END OF TERMS AND CONDITIONS_

### MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

### ST Microelectronics - SLA0044 - ULTIMATE LIBERTY SOFTWARE LICENSE AGREEMENT

BY INSTALLING, COPYING, DOWNLOADING, ACCESSING OR OTHERWISE USING THIS SOFTWARE OR ANY PART
THEREOF (AND THE RELATED DOCUMENTATION) FROM STMICROELECTRONICS INTERNATIONAL N.V, SWISS
BRANCH AND/OR ITS AFFILIATED COMPANIES (STMICROELECTRONICS), THE RECIPIENT, ON BEHALF OF HIMSELF
OR HERSELF, OR ON BEHALF OF ANY ENTITY BY WHICH SUCH RECIPIENT IS EMPLOYED AND/OR ENGAGED
AGREES TO BE BOUND BY THIS SOFTWARE LICENSE AGREEMENT.
Under STMicroelectronics’ intellectual property rights, the redistribution, reproduction and use in source and binary forms of the
software or any part thereof, with or without modification, are permitted provided that the following conditions are met:
1. Redistribution of source code (modified or not) must retain any copyright notice, this list of conditions and the disclaimer
set forth below as items 10 and 11.
2. Redistributions in binary form, except as embedded into microcontroller or microprocessor device manufactured by or for
STMicroelectronics or a software update for such device, must reproduce any copyright notice provided with the binary
code, this list of conditions, and the disclaimer set forth below as items 10 and 11, in documentation and/or other materials
provided with the distribution.
3. Neither the name of STMicroelectronics nor the names of other contributors to this software may be used to endorse or
promote products derived from this software or part thereof without specific written permission.
4. This software or any part thereof, including modifications and/or derivative works of this software, must be used and
execute solely and exclusively on or in combination with a microcontroller or microprocessor device manufactured by or for
STMicroelectronics.
5. No use, reproduction or redistribution of this software partially or totally may be done in any manner that would subject this
software to any Open Source Terms. “Open Source Terms” shall mean any open source license which requires as part of
distribution of software that the source code of such software is distributed therewith or otherwise made available, or open
source license that substantially complies with the Open Source definition specified at www.opensource.org and any other
comparable open source license such as for example GNU General Public License (GPL), Eclipse Public License (EPL),
Apache Software License, BSD license or MIT license.
6. STMicroelectronics has no obligation to provide any maintenance, support or updates for the software.
7. The software is and will remain the exclusive property of STMicroelectronics and its licensors. The recipient will not take
any action that jeopardizes STMicroelectronics and its licensors' proprietary rights or acquire any rights in the software,
except the limited rights specified hereunder.
8. The recipient shall comply with all applicable laws and regulations affecting the use of the software or any part thereof
including any applicable export control law or regulation.
9. Redistribution and use of this software or any part thereof other than as permitted under this license is void and will
automatically terminate your rights under this license.
10. THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS,
IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY
INTELLECTUAL PROPERTY RIGHTS, WHICH ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN
NO EVENT SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
11. EXCEPT AS EXPRESSLY PERMITTED HEREUNDER, NO LICENSE OR OTHER RIGHTS, WHETHER EXPRESS OR
IMPLIED, ARE GRANTED UNDER ANY PATENT OR OTHER INTELLECTUAL PROPERTY RIGHTS OF
STMICROELECTRONICS OR ANY THIRD PARTY.
